package com.scsa.java.sixth;

public class Book {
	private String isbn, title, author, publisher, desc;
	private int price;
	
	
	public Book(String isbn, String title, String author, String publisher, int price, String desc) {
		super();
		setIsbn(isbn);
		setTitle(title);
		setAuthor(author);
		setPublisher(publisher);
		setPrice(price);
		setDesc(desc);
	}
	
	
	public Book(String isbn, String title, String author, String publisher, int price) {
		this(isbn, title, author, publisher, price, "");
	}


	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		if(isbn != null) {
			this.isbn = isbn;
		}else {
			System.out.println("invalid isbn");
		}
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		if(title != null) {
			this.title = title;
		}else {
			System.out.println("invalid title");
		}
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		if(author != null) {
			this.author = author;
		}else {
			System.out.println("invalid author");
		}
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		if(publisher != null) {
			this.publisher = publisher;
		}else {
			System.out.println("invalid publisher");
		}
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		if(desc != null) {
			this.desc = desc;
		}else {
			System.out.println("invalid desc");
		}
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		if(price > 0) {
			this.price = price;
		}else {
			System.out.println("invalid price");
		}
	}
	
	public String toString() {
		return getIsbn() + "\t| " + getTitle() + "\t| " + getAuthor() + "\t| " + getPublisher() + "\t| " + getPrice() + "\t| " + getDesc();
	}

}