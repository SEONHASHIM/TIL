package com.scsa.java.sixth;

public class Magazine {
	private String isbn, title, author, publisher, desc;
	private int  year, month, price;
	
	
	public Magazine(String isbn, String title, String author, String publisher, int price, String desc, int year, int month) {
		super();
		setIsbn(isbn);
		setTitle(title);
		setAuthor(author);
		setPublisher(publisher);
		setPrice(price);
		setDesc(desc);
		setYear(year);
		setMonth(month);
	}
	
	
	
	public Magazine(String isbn, String title, String author, String publisher, int price, int year, int month) {
		this(isbn,title,author,publisher,price,"",year,month);
	}


	public String getIsbn() {
		return isbn;
	}
	public void setIsbn(String isbn) {
		if(isbn != null) {
			this.isbn = isbn;
		}else {
			System.out.println("invalid isbn");
		}
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		if(title != null) {
			this.title = title;
		}else {
			System.out.println("invalid title");
		}
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		if(author != null) {
			this.author = author;
		}else {
			System.out.println("invalid author");
		}
	}
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		if(publisher != null) {
			this.publisher = publisher;
		}else {
			System.out.println("invalid publisher");
		}
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		if(desc != null) {
			this.desc = desc;
		}else {
			System.out.println("invalid desc");
		}
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		if(price > 0) {
			this.price = price;
		}else {
			System.out.println("invalid price");
		}
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		if(year>0 && year<2022) {
			this.year = year;
		}else {
			System.out.println("invalid year");
		}
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		if(month>0 && month<13) {
			this.month = month;
		}else {
			System.out.println("invalid month");
		}
	}
	
	public String toString() {
		return getIsbn() + "\t| " + getTitle() + "\t| " + getAuthor() + "\t| " + getPublisher() + "\t| " + getPrice() + "\t| " + getDesc() + "\t| " + getYear() + "." + getMonth() ;
	}

}
