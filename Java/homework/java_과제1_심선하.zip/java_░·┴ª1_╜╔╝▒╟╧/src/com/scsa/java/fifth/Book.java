package com.scsa.java.fifth;

public class Book {
	String isbn, title, author, publisher, desc;
	int price;
	
	public String toString() {
		return isbn + "\t| " + title + "\t| " + author + "\t| " + publisher + "\t| " + price + "\t| " + desc;
	}

}
