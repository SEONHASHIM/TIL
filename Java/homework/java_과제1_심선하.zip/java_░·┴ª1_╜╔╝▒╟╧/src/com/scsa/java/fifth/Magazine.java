package com.scsa.java.fifth;

public class Magazine {
	String isbn, title, author, publisher, desc;
	int  year, month, price;
	
	public String toString() {
		return isbn + "\t| " + title + "\t| " + author + "\t| " + publisher + "\t| " + price + "\t| " + desc + "\t| " + year + "." + month;
	}

}
